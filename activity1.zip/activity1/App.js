import React from 'react';
import {StyleSheet, Text, ScrollView, StatusBar} from 'react-native';
import {SafeAreaView, SafeAreaProvider} from 'react-native-safe-area-context';

const App = () => (
  <SafeAreaProvider>
    <SafeAreaView style={styles.container} edges={['top']}>
      <ScrollView style={styles.scrollView}>
        <Text style={styles.text}>
         DREAM (lyrics) 
         Sometimes I don't know who I am
Doubting myself again
Can't find a light in the dark
And I'm finding myself in the rain
Tryna get out of the pain
Know that I've come so far
I made a promise, I'll never run and hide
I'm getting stronger
I'm getting stronger
A little longer
I'm getting stronger
Now I finally found my wings
I let go of everything
Decided to follow my heart
And I'm finally able to breathe
Finally able to see
Just who I was born to be
I'm waking up in my dream
Uh, oh yeah, that fire's in my eyes
No sleep, you keep them lullabies
Cross hearts, I've been the one to ride
Vroom-vroom, I'll see you later, bye
I keep it a hundred, we one in a million, no billion
No kiddin', no ceiling, that's limitless
Stars in the sky, we infinite
Envisioned it, just how I pictured it
Here we are, all of the lights, spotlight is blinding my eyes
Just breathe and live and let it die
Lift up my head, I'ma rise
Spread out my wings, I'm a fly, fly high
I'm getting stronger
I'm getting stronger
A little longer
I'm getting stronger
Now I finally found my wings
I let go of everything
Decided to follow my heart
I don't care what they say (say)
My life is not a game (game)
Never gon' run away
So don't wake me up (finally able to breathe)
Yeah-yeah-yeah
Can't wake me up (nothing can wake me up)
I'm waking up in my dream
        </Text>
      </ScrollView>
    </SafeAreaView>
  </SafeAreaProvider>
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingTop: StatusBar.currentHeight,
  },
  scrollView: {
    backgroundColor: '#87cefa',
  },
  text: {
    fontSize: 42,
    padding: 12,
  },
});

export default App;